# ZEROFLIX Android WebView Project

This Android Studio project wraps the deployed ZEROFLIX website in a native Android WebView.

## Build APK
1. Open this folder in Android Studio.
2. Let Gradle sync/download the Android Gradle Plugin and dependencies.
3. Open **Build > Generate App Bundles or APKs > Generate APKs**.
4. The debug APK will be in `app/build/outputs/apk/debug/app-debug.apk`.

## Website URL
The app currently opens:
`https://fastidious-maamoul-0c43f9.netlify.app/`

If your latest ZEROFLIX deployment has another URL, edit `START_URL` in:
`app/src/main/java/com/zeroflix/app/MainActivity.java`

## Important
- Internet permission is enabled.
- JavaScript, DOM storage, cookies and file chooser are enabled for the website.
- Admin video upload can open Android's file picker.
- Firebase/Google authentication behavior depends on the website's OAuth configuration. Some Google OAuth flows do not allow embedded WebViews; in that case the website should use an external browser/custom tab for Google sign-in.
