# ZEROFLIX APK — phone-only build

You do NOT need a laptop for this method. GitHub Actions builds the APK online.

1. Create a GitHub account and a new repository (for example `zeroflix-android`).
2. Upload the contents of this folder to the repository's `main` branch.
3. Open the repository → **Actions** → **Build ZEROFLIX APK** → **Run workflow**.
4. Wait for the workflow to finish with a green check.
5. Open the completed workflow run → **Artifacts** → download `ZEROFLIX-debug-APK`.
6. Extract the downloaded ZIP and install `app-debug.apk` on your Android phone.

If GitHub asks for permission to run workflows, allow it for your repository.
